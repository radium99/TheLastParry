#include "MouseTester.h"
#include "Core/Input.h"
#include "Render/Renderer.h"
#include "Engine/Engine.h"
#include <iostream>

MouseTester::MouseTester()
	: super(" ", Vector2(Engine::Get().GetWidth() / 2, Engine::Get().GetHeight() - 1))
{
}

void MouseTester::Tick(float deltaTime)
{
	super::Tick(deltaTime);

	// ���콺 �Է� �׽�Ʈ.
	//if (Input::Get().GetMouseButton(0))
	//{
		Vector2 mousePosition = Input::Get().MousePosition();
		char buffer[256] = {};
		sprintf_s(
			buffer, 
			256, 
			"cursor: (%d, %d)", 
			mousePosition.x, 
			mousePosition.y
		);

		ChangeImage(buffer);
	//}
}
